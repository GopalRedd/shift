package com.my360crm.my360access.NewCustomerPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.my360crm.my360access.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360access.JsonNetworkPackage.MultipartRequest;
import com.my360crm.my360access.R;
import com.my360crm.my360access.Settings.Settings;
import com.my360crm.my360access.StartCamera;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class RegisterUserByAdmin extends AppCompatActivity {

    private static final String TAG = RegisterUserByAdmin.class.getSimpleName();
    TextInputLayout namelay,emaillay,phonelay,typelay,addresslay;
    TextInputEditText name,email,phone,type,address;
    TextView oldname;
    Button next;
    ImageView imageView;
    Bitmap b;
    Bundle bundle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user_by_admin);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        name = findViewById(R.id.fnameedit);
        email = findViewById(R.id.emailedt);
        phone = findViewById(R.id.phoneedt);
        type = findViewById(R.id.typeedit);
        address = findViewById(R.id.addressedit);
        next = findViewById(R.id.registernow);
        imageView = findViewById(R.id.reguser_profile_photo);
        oldname = findViewById(R.id.oldname);
        namelay = findViewById(R.id.fnamelay);
        emaillay = findViewById(R.id.emaillay);
        phonelay = findViewById(R.id.phonelay);
        typelay = findViewById(R.id.typelay);
        addresslay = findViewById(R.id.addresslay);

        bundle = getIntent().getExtras();
        assert bundle != null;

        if(getIntent().hasExtra("image"))
        {
            b = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("image"), 0, Objects.requireNonNull(getIntent().getByteArrayExtra("image")).length);
            imageView.setImageBitmap(getCircularBitmap(b));
        }else /*if(getIntent().hasExtra("status") || getIntent().hasExtra("name") || getIntent().hasExtra("type") || getIntent().hasExtra("url") )*/
        {

           oldname.setVisibility(View.VISIBLE);
           namelay.setVisibility(View.INVISIBLE);
           emaillay.setVisibility(View.INVISIBLE);
           phonelay.setVisibility(View.INVISIBLE);
           typelay.setVisibility(View.INVISIBLE);
           addresslay.setVisibility(View.INVISIBLE);
            name.setVisibility(View.INVISIBLE);
            email.setVisibility(View.INVISIBLE);
            phone.setVisibility(View.INVISIBLE);
            type.setVisibility(View.INVISIBLE);
            address.setVisibility(View.INVISIBLE);
            next.setVisibility(View.INVISIBLE);
            String status        = bundle.getString("status");
            String userstatus    = bundle.getString("name");
            final String faceid  = bundle.getString("type");
            String faceurl       = bundle.getString("url");
            oldname.setTextColor(this.getResources().getColor(R.color.red));
            oldname.setText("Hi"+" "+userstatus);
            Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "name " + userstatus + "\n" + "type " + faceid + "\n" + "url " + faceurl + "\n" + "===========================\n");
            SetProfilePic(faceurl);
            Snackbar.make(findViewById(android.R.id.content),"Already User",Snackbar.LENGTH_LONG).show();

        }

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                String namestring = name.getText().toString();
                String emailstring = email.getText().toString();
                String phonestring = phone.getText().toString();
                String positionstring = type.getText().toString();
                String addressstring = address.getText().toString();

                ValidationsNow(namestring,emailstring,phonestring,positionstring,addressstring);
            }
        });


        
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(RegisterUserByAdmin.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(RegisterUserByAdmin.this, NewCustomer.class));
                    finish();
                }
            }, 1000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Intent i=new Intent(RegisterUserByAdmin.this, NewCustomer.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }




    private void SetProfilePic(String faceurl) {
        final Target mTarget = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                Log.d("DEBUG", "onBitmapLoaded");
                //progress_bar.setVisibility(View.GONE);
                imageView.setImageBitmap(getCircularBitmap(bitmap));
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                Log.d("DEBUG", "onBitmapFailed");
            }


            @Override
            public void onPrepareLoad(Drawable drawable) {
                Log.d("DEBUG", "onPrepareLoad");
            }
        };
        Picasso.get().load(faceurl).into(mTarget);
        imageView.setTag(mTarget);
    }

    private void ValidationsNow(String namestring, String emailstring, String phonestring, String positionstring, String addressstring) {


        if(namestring.isEmpty())
        {
            Snackbar.make(findViewById(android.R.id.content),"Please Enter name",Snackbar.LENGTH_LONG).show();
        }else if(phonestring.isEmpty())
        {
            Snackbar.make(findViewById(android.R.id.content),"Please Enter Phonenumber",Snackbar.LENGTH_LONG).show();

        }else if(emailstring.isEmpty())
        {
            Snackbar.make(findViewById(android.R.id.content),"Please Enter Email",Snackbar.LENGTH_LONG).show();

        }else  if(positionstring.isEmpty())
        {
            Snackbar.make(findViewById(android.R.id.content),"Please Enter Type",Snackbar.LENGTH_LONG).show();
        }else  if(addressstring.isEmpty())
        {
            Snackbar.make(findViewById(android.R.id.content),"Please Enter Address",Snackbar.LENGTH_LONG).show();
        }else
        {
            Log.i(TAG,"Ok");
            Uploadnow(namestring,emailstring,phonestring,positionstring,addressstring,b);

        }


    }

    private void Uploadnow(final String namestring, final String emailstring, final String phonestring, final String positionstring, final String addressstring, final Bitmap b) {


        circularprogresssdialog.showDialog(RegisterUserByAdmin.this,"","");

        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/RegisterUser.php", new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {

                circularprogresssdialog.dismissdialog();

                try {
                    JSONObject object = new JSONObject(new String(response.data));
                    Log.i(TAG,object.toString());

                    String Status = object.getString("status");

                    if(Status.equals("success"))
                    {
                        String Name = object.getString("name");
                        String Type = object.getString("type");
                        Snackbar.make(findViewById(android.R.id.content),"Successfully Registered " +Name+" As a "+Type,Snackbar.LENGTH_LONG).show();

                        circularprogresssdialog.showDialog(RegisterUserByAdmin.this,"","");
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                circularprogresssdialog.dismissdialog();
                                Intent intent = new Intent(RegisterUserByAdmin.this,StartCamera.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();


                            }
                        },2000);


                    } else if(Status.equals("error"))
                    {
                        String Result = object.getString("result");
                        Snackbar.make(findViewById(android.R.id.content),Result,Snackbar.LENGTH_LONG).show();



                        circularprogresssdialog.showDialog(RegisterUserByAdmin.this,"","");
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                circularprogresssdialog.dismissdialog();
                        Intent intent = new Intent(RegisterUserByAdmin.this,NewCustomer.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();

                            }
                        },2000);


                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                circularprogresssdialog.dismissdialog();
                Log.e(TAG,"Something error "+error.getMessage());

                try {
                    NetworkResponse response = error.networkResponse;
                    VolleyError responseError = new VolleyError( new String(error.networkResponse.data));
                    Log.i(TAG,"res" +String.valueOf(responseError));
                    String errorMsg = "";

                    String errorString = new String(response.data);
                    Log.i("log error", errorString);
                    int mstatuscode = response.statusCode;
                    Log.i(TAG, String.valueOf(mstatuscode));
                    if(mstatuscode == HttpURLConnection.HTTP_NOT_FOUND)
                    {
                        Snackbar.make(findViewById(android.R.id.content), mstatuscode +" Server Not Found",Snackbar.LENGTH_LONG).show();
                    } else if(mstatuscode == HttpURLConnection.HTTP_INTERNAL_ERROR)
                    {
                        Snackbar.make(findViewById(android.R.id.content), mstatuscode +" Internal Server Error",Snackbar.LENGTH_LONG).show();

                    }else  if(response.statusCode == 401)
                    {
                        Snackbar.make(findViewById(android.R.id.content), mstatuscode +" Unauthorized Error",Snackbar.LENGTH_LONG).show();

                    } else
                    {
                        Snackbar.make(findViewById(android.R.id.content), "Bad Internet try again!",Snackbar.LENGTH_LONG).show();
                    }
                }catch (Exception e )
                {
                    e.printStackTrace();
                    Log.i(TAG, "cause"+String.valueOf(e.getCause()));
                    Log.i(TAG, "Local"+String.valueOf(e.getLocalizedMessage()));
                    Log.i(TAG, "Message"+String.valueOf(e.getMessage()));
                    Log.i(TAG, "Message"+String.valueOf(e.toString()));

                }
                Snackbar.make(findViewById(android.R.id.content),"Something went Wrong..Please Check internet connection!",Snackbar.LENGTH_LONG).show();


            }
        }){


            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                params.put("name",namestring);
                params.put("email",emailstring);
                params.put("mobile_no",phonestring);
                params.put("type",positionstring);
                params.put("address",addressstring);
                return params;
            }


            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("image", new MultipartRequest.DataPart(imagename + ".jpeg", getFileDataFromDrawable(b)));
                return params;
            }


        };multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,DefaultRetryPolicy.DEFAULT_MAX_RETRIES ,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(multipartRequest);



    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {

        if (bitmap != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream);
            Log.i(TAG, byteArrayOutputStream.toByteArray().toString());
            return byteArrayOutputStream.toByteArray();

        } else {
            Log.i(TAG, "Bitmap is Empty ");

            return null;
        }
    }



    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }

}
