package com.my360crm.my360access.AdminConformationPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.my360crm.my360access.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360access.JsonNetworkPackage.MultipartRequest;
import com.my360crm.my360access.MainActivity;
import com.my360crm.my360access.R;
import com.my360crm.my360access.Settings.Settings;
import com.my360crm.my360access.StartCamera;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Admin_confirm extends AppCompatActivity implements Animation.AnimationListener {

    private static  final String TAG = Admin_confirm.class.getSimpleName();
    private Bitmap b;
    private EditText pinnumber;
    private TextView user_profile_names;
    private ImageView imageView;
    ImageView anim;
    Animation animFadeOut;
    private Bundle bundle;
    private Button register,cancel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_confirm);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Log.i(TAG,"Admin");
        animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation);
        pinnumber = findViewById(R.id.userpinnub);
        user_profile_names = findViewById(R.id.user_profile_names);
        imageView = findViewById(R.id.user_profile_photo);
        anim = findViewById(R.id.animationimage);
        register=findViewById(R.id.register1);
        cancel=findViewById(R.id.cancel1);
        bundle = getIntent().getExtras();
        assert bundle != null;
        if(getIntent().hasExtra("image"))
        {
            b = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("image"),0,
                    Objects.requireNonNull(getIntent().getByteArrayExtra("image")).length);
            Log.i(TAG,b.toString());

/*            anim.setVisibility(View.VISIBLE);
            anim.setImageResource(R.drawable.wrong);
            anim.startAnimation(animFadeOut);*/
            imageView.setImageBitmap(getCircularBitmap(b));
            pinnumber.setVisibility(View.VISIBLE);
            register.setVisibility(View.VISIBLE);
            cancel.setVisibility(View.VISIBLE);
            user_profile_names.setTextColor(this.getResources().getColor(R.color.black));
            user_profile_names.setText(R.string.passcode);

        } else
        {

            anim.setVisibility(View.VISIBLE);
            anim.setImageResource(R.drawable.correct);
            anim.startAnimation(animFadeOut);
            String status        = bundle.getString("status");
            String userstatus    = bundle.getString("name");
            final String faceid  = bundle.getString("type");
            String faceurl       = bundle.getString("url");
            user_profile_names.setTextColor(this.getResources().getColor(R.color.red));
            user_profile_names.setText("Hi"+" "+userstatus);
            Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "name " + userstatus + "\n" + "type " + faceid + "\n" + "url " + faceurl + "\n" + "===========================\n");
            SetProfilePic(faceurl);
            Snackbar.make(findViewById(android.R.id.content),"Hi " + faceid + " " +userstatus +" Welcome",Snackbar.LENGTH_LONG).show();

            circularprogresssdialog.showDialog(Admin_confirm.this,"","");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                  circularprogresssdialog.dismissdialog();
                  Intent intent = new Intent(Admin_confirm.this, Settings.class);
                  startActivity(intent);
                  finish();

                }
            },5000);


        }

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String  passcode = pinnumber.getText().toString();

                if(passcode.length() == 6)
                {
                    Validateuserwithpasscode(passcode,b);
                    Log.i(TAG,passcode);
                    Log.i(TAG,"Reg "+passcode);
                } else
                {
                    pinnumber.setError("Invalid Please enter 6 digits code");
                }


            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Admin_confirm.this, MainActivity.class));
                finish();

            }
        });

    }

    private void SetProfilePic(String faceurl) {
        final Target mTarget = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                Log.d("DEBUG", "onBitmapLoaded");
                //progress_bar.setVisibility(View.GONE);
                imageView.setImageBitmap(getCircularBitmap(bitmap));
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                Log.d("DEBUG", "onBitmapFailed");
            }


            @Override
            public void onPrepareLoad(Drawable drawable) {
                Log.d("DEBUG", "onPrepareLoad");
            }
        };
        Picasso.get().load(faceurl).into(mTarget);
        imageView.setTag(mTarget);
    }

    private void Validateuserwithpasscode(final String passcode, final Bitmap b) {

        circularprogresssdialog.showDialog(Admin_confirm.this,"","");
        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/AWS.php", new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                circularprogresssdialog.dismissdialog();
                try {
                    JSONObject obj = new JSONObject(new String(response.data));
                    Log.i(TAG, obj.toString());
                    String Status = obj.getString("status");
                    if (Status.equals("success")) {
                        String Name = obj.getString("name");
                        String Type = obj.getString("type");
                        Log.i(TAG,Name);
                        Log.i(TAG,Type);
                        Snackbar.make(findViewById(android.R.id.content),"Hi "+Name +" Successfully Verified!" ,Snackbar.LENGTH_LONG).show();
                        user_profile_names.setVisibility(View.VISIBLE);
                        user_profile_names.setText("Hi "+Name);
                        anim.setVisibility(View.VISIBLE);
                        anim.setImageResource(R.drawable.rite);
                        anim.startAnimation(animFadeOut);
                        pinnumber.setVisibility(View.INVISIBLE);
                        register.setVisibility(View.INVISIBLE);
                        cancel.setVisibility(View.INVISIBLE);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startActivity(new Intent(Admin_confirm.this, StartCamera.class));
                                finish();
                            }
                        },2000);

                    } else if(Status.equals("error"))
                    {
                        String result = obj.getString("result");
                        Log.i(TAG,result);
                        Snackbar.make(findViewById(android.R.id.content),result,Snackbar.LENGTH_LONG).show();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                startActivity(new Intent(Admin_confirm.this, StartCamera.class));
                                finish();
                            }
                        },2000);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override //Something Went Wrong We are Working...
            public void onErrorResponse(VolleyError error) {
                circularprogresssdialog.dismissdialog();
                Log.e(TAG,"Something error "+error.getMessage());

                try {
                    NetworkResponse response = error.networkResponse;
                    VolleyError responseError = new VolleyError( new String(error.networkResponse.data));
                    Log.i(TAG,"res" +String.valueOf(responseError));
                    String errorMsg = "";

                    String errorString = new String(response.data);
                    Log.i("log error", errorString);
                    int mstatuscode = response.statusCode;
                    Log.i(TAG, String.valueOf(mstatuscode));
                    if(mstatuscode == HttpURLConnection.HTTP_NOT_FOUND)
                    {
                        Snackbar.make(findViewById(android.R.id.content), mstatuscode +" Server Not Found",Snackbar.LENGTH_LONG).show();
                    } else if(mstatuscode == HttpURLConnection.HTTP_INTERNAL_ERROR)
                    {
                        Snackbar.make(findViewById(android.R.id.content), mstatuscode +" Internal Server Error",Snackbar.LENGTH_LONG).show();

                    }else  if(response.statusCode == 401)
                    {
                        Snackbar.make(findViewById(android.R.id.content), mstatuscode +" Unauthorized Error",Snackbar.LENGTH_LONG).show();

                    } else
                    {
                        Snackbar.make(findViewById(android.R.id.content), "Bad Internet try again!",Snackbar.LENGTH_LONG).show();
                    }
                }catch (Exception e )
                {
                    e.printStackTrace();
                    Log.i(TAG, "cause"+String.valueOf(e.getCause()));
                    Log.i(TAG, "Local"+String.valueOf(e.getLocalizedMessage()));
                    Log.i(TAG, "Message"+String.valueOf(e.getMessage()));
                    Log.i(TAG, "Message"+String.valueOf(e.toString()));

                }
                Snackbar.make(findViewById(android.R.id.content),"Something went Wrong..Please Check internet connection!",Snackbar.LENGTH_LONG).show();


            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                //params.put("tags", tags);
                return params;
            }


            /*
             * Here we are passing image by renaming it with a unique name
             *
             */

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put(passcode, new DataPart(imagename + ".jpeg", getFileDataFromDrawable(b)));
                Log.i(TAG,passcode);
                return params;
            }

        };multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,DefaultRetryPolicy.DEFAULT_MAX_RETRIES ,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(multipartRequest);
    }


    private byte[] getFileDataFromDrawable(Bitmap bitmap) {
        if(bitmap != null)
        {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream);
            Log.i(TAG,byteArrayOutputStream.toByteArray().toString());
            return byteArrayOutputStream.toByteArray();

        } else
        {
            Log.i(TAG,"Bitmap is Empty ");

            return null;
        }


    }

    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }


    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
