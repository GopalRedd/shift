package com.my360crm.my360access.Settings;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.my360crm.my360access.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360access.NewCustomerPackage.NewCustomer;
import com.my360crm.my360access.R;
import com.my360crm.my360access.StartCamera;

import java.util.Objects;
import java.util.Set;

public class Settings extends AppCompatActivity implements View.OnClickListener {


    private Button adduser,settings;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        adduser = findViewById(R.id.adduser);
        settings = findViewById(R.id.settings);


        adduser.setOnClickListener(this);
        settings.setOnClickListener(this);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(Settings.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(Settings.this, StartCamera.class));
                    finish();
                }
            }, 1000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Intent i=new Intent(Settings.this, StartCamera.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }


    @Override
    public void onClick(View view)
    {

        switch (view.getId())
        {
            case R.id.adduser:

                Intent intent = new Intent(Settings.this, NewCustomer.class);
                startActivity(intent);
                finish();
                break;

            case R.id.settings:
                Intent intent1 = new Intent(Settings.this,LocalSettings.class);
                startActivity(intent1);
                finish();
                break;

        }



    }
}
