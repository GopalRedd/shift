package com.my360crm.my360access.NewCustomerPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.my360crm.my360access.AccessPackage.AccessCam;
import com.my360crm.my360access.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360access.R;
import com.my360crm.my360access.Settings.Settings;
import com.my360crm.my360access.StartCamera;

import java.util.Objects;

public class NewCustomer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_customer);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Intent i=new Intent(NewCustomer.this, StartCamera.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(NewCustomer.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(NewCustomer.this, StartCamera.class));
                    finish();
                }
            }, 1000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    public void Touchtostart(View view)
    {

        circularprogresssdialog.showDialog(NewCustomer.this,"","");
        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                circularprogresssdialog.dismissdialog();
                startActivity(new Intent(NewCustomer.this, CustomerStartCamera.class));
                finish();
            }
        },2000);


    }



}
