package com.my360crm.my360access.RegistrationWithCodePackage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.my360crm.my360access.R;

public class Registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }
}
