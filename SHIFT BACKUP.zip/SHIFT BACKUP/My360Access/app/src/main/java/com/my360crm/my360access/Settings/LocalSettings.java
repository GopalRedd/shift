package com.my360crm.my360access.Settings;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.my360crm.my360access.AccessPackage.ImagePreview;
import com.my360crm.my360access.CircularProgressdialog.circularprogresssdialog;
import com.my360crm.my360access.NewCustomerPackage.NewCustomer;
import com.my360crm.my360access.R;
import com.my360crm.my360access.StartCamera;

import java.util.Arrays;
import java.util.List;

public class LocalSettings extends AppCompatActivity implements View.OnClickListener {


    private Button modifiy_logo, resizecam;
    private AlertDialog.Builder alertDialog;
    private ImageView imageView, imageView1;
    private static int RESULT_LOAD_IMAGE = 1;
    private Uri mImageUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_settings);

        modifiy_logo = findViewById(R.id.addorcancel);
        resizecam = findViewById(R.id.resizecamera);
        imageView = findViewById(R.id.modifiy);
        imageView1 = findViewById(R.id.modifiy1);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String mImageUri = preferences.getString("image", null);

        if (mImageUri != null) {
            imageView1.setImageURI(Uri.parse(mImageUri));
        } else {
            imageView1.setImageResource(R.color.white);
        }


        modifiy_logo.setOnClickListener(this);
        resizecam.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {


        switch (view.getId()) {
            case R.id.addorcancel:
                getImage();
                break;

            case R.id.resizecamera:

                showCustomdialog();

                break;


        }

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent i=new Intent(LocalSettings.this, Settings.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(LocalSettings.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(LocalSettings.this, Settings.class));
                    finish();
                }
            }, 1000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }






    private void showCustomdialog() {


        final String names[] = {"High", "Meduim", "Low", "Default", "Cancel"};
        alertDialog = new AlertDialog.Builder(LocalSettings.this);
        LayoutInflater inflater = getLayoutInflater();
        View convertView = (View) inflater.inflate(R.layout.custom_alert_dialog, null);
        alertDialog.setView(convertView);
        ListView lv = (ListView) convertView.findViewById(R.id.lv);
        /*ArrayAdapter<String> adapter = new  ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names);
         */
        final AlertDialog alert = alertDialog.create();
        MyAdapter myadapter = new MyAdapter(getApplication(), R.layout.alertlist_item_text, names);

        lv.setAdapter(myadapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 4) {
                    alert.cancel();
                } else {

                    circularprogresssdialog.showDialog(LocalSettings.this, "", "");
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            circularprogresssdialog.dismissdialog();
                            alert.cancel();
                            startActivity(new Intent(LocalSettings.this, NewCustomer.class));
                            finish();

                        }
                    }, 1000);

                }
            }
        });
        alert.show();


    }


    private void getImage() {
        Intent intent;
        if (Build.VERSION.SDK_INT < 19) {
            intent = new Intent(Intent.ACTION_GET_CONTENT);
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
        }
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);

    }


    private class MyAdapter extends ArrayAdapter<String> {

        LayoutInflater inflater;

        Context myContext;

        List<String> newList;

        public MyAdapter(Context context, int resource, String[] list) {

            super(context, resource, list);

            // TODO Auto-generated constructor stub

            myContext = context;

            newList = Arrays.asList(list);

            inflater = LayoutInflater.from(context);

        }

        private class ViewHolder {

            TextView tvSname;

        }


        @Override

        public View getView(final int position, View view, ViewGroup parent) {

            final ViewHolder holder;

            if (view == null) {

                holder = new ViewHolder();

                view = inflater.inflate(R.layout.alertlist_item_text, null);

                holder.tvSname = (TextView) view.findViewById(R.id.item);

                view.setTag(holder);

            } else {

                holder = (ViewHolder) view.getTag();

            }

            holder.tvSname.setText(newList.get(position).toString());

            return view;

        }
    }
   // {"status":"error","result":"Image not found"}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == RESULT_OK && null != data) {


            if (data != null) {

                mImageUri = data.getData();


                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("image", String.valueOf(mImageUri));
                editor.commit();

                imageView1.setImageURI(mImageUri);
                imageView1.invalidate();

            }

        }
    }
}